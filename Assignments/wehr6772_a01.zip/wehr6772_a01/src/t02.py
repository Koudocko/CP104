"""
-------------------------------------------------------
States the user's age and favourite band
-------------------------------------------------------
Author:  Tyler Wehrle
ID:      169056772
Email:   wehr6772@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""

# Get age and favourite band inputs
age = int(input("What is your age? "))
favourite_band = input("What is your favourite band? ")

# Display the user's age and favourite band
print(f"I am {age} years old and {favourite_band} is my favourite band.")
