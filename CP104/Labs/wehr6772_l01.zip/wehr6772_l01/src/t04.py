"""
-------------------------------------------------------
Greets you according to your specified name
-------------------------------------------------------
Author:  Tyler Wehrle
ID:      169056772
Email:   wehr6772@mylaurier.ca
__updated__ = "2023-09-09"
-------------------------------------------------------
"""

name = input("Please enter your name: ")
print("Pleased to meet you ")
print(name)
