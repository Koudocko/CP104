"""
-------------------------------------------------------
Calculates your pay based on salary and bonus
-------------------------------------------------------
Author:  Tyler Wehrle
ID:      169056772
Email:   wehr6772@mylaurier.ca
__updated__ = "2023-09-09"
-------------------------------------------------------
"""

# Calculate total pay
salary = 2500.0
bonus = 1200.0
pay = salary + bonus
print('Your pay is', pay)
