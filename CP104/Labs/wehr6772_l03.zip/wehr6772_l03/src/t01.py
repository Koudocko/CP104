"""
-------------------------------------------------------
Outputs a multiline excerpt to the console
-------------------------------------------------------
Author:  Tyler Wehrle
ID:      169056772
Email:   wehr6772@mylaurier.ca
__updated__ = "2023-09-09"
-------------------------------------------------------
"""

# Outputs the multiline string
print("""
'I'm a Little Astronaut' by Jean Warren

I'm a little astronaut
    Flying to the moon.
        My rocket is ready,
        We blast off soon.
I climb aboard
    And close the hatch.
        5-4-3-2-1, off we blast!
""")
